function calculateFibonacci() {
	const countInput = document.getElementById('count');
	const resultDisplay = document.getElementById('result');
	const count = parseInt(countInput.value);

	if (isNaN(count) || count < 0) {
		resultDisplay.textContent = 'Please enter a non-negative number.';
		return;
	}

	if (count === 0) {
		resultDisplay.textContent = 'Fibonacci(0) = 0';
	} else if (count === 1) {
		resultDisplay.textContent = 'Fibonacci(1) = 1';
	} else {
		let fib1 = 0;
		let fib2 = 1;
		let fibonacci = 0;

		for (let i = 2; i <= count; i++) {
			fibonacci = fib1 + fib2;
			fib1 = fib2;
			fib2 = fibonacci;
		}

		resultDisplay.textContent = `Fibonacci(${count}) = ${fibonacci}`;
	}
}