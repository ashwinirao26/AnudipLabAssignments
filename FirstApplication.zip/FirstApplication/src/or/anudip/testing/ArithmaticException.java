package or.anudip.testing;

public class ArithmaticException {

}
