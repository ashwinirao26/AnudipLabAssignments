package or.anudip.testing;
import static org.junit.jupiter.api.Assertions.*;
import org.anudip.application.Votor;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class VotorTest {
@ParameterizedTest
@CsvSource(value= {"19, true","21,true","15, false","21,true"})
void testValidVotorCheck(int age,boolean expected) {
	Votor votor = new Votor();
	assertEquals(expected,votor.validVotorCheck(age));
}
}
