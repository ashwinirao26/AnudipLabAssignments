package PracticeQs;

import java.util.Scanner;

public class ExtractingCharFromString6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String s = sc.nextLine();
		String str = "";
		
		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i)>='a' && s.charAt(i)<='z' || s.charAt(i)>='A' && s.charAt(i)<='Z') {
				str = str+s.charAt(i);
			}
		}
		System.out.println(str);
	}
}
