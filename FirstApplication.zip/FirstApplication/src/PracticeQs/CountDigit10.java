package PracticeQs;

import java.util.Scanner;

public class CountDigit10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Number");
		int num = sc.nextInt(); //taking input from user
		int count = 0;
		int temp = num; // storing the num value in temp 
		
		while(num!=0) {
			num = num/10; 
			count++;
		}
		System.out.println("Total number of digits in "+temp+" are "+count);
	}

}
