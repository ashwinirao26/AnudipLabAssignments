package PracticeQs;

import java.util.Scanner;
public class ArmstrongNo1 {
	public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a Number");
	        int num = sc.nextInt();
	        int arm = 0, rem;
	        int temp = num ;

	        while (num > 0) {
	            rem = num % 10;
	            arm = arm + (rem * rem * rem);
	            num = num / 10;
	        }
	        if(temp == arm){
	            System.out.println("Armstrong");
	        }
	        else{
	            System.out.println("Not an Armstrong");
	        }
	}
}
