package org.anudip.app;

import java.util.Scanner;

public class Perimeter {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Shape");
		String shape = sc.nextLine();
		
		switch(shape) {
		case "circle":
			System.out.print("Enter the radious: ");
			int r = sc.nextInt();
			int perimeter1 = 2*(22/7)*r;
			System.out.println("Perimeter of a Circle: "+perimeter1);
			break;

		case "square":
			System.out.print("Enter the sides: ");
			int s = sc.nextInt();
			int perimeter2 = 4*s;;
			System.out.println("Perimeter of a Square: "+perimeter2);
			break;
			
		case "rectangle":
			System.out.print("Enter the length: ");
			int l = sc.nextInt();
			System.out.print("Enter the Base: ");
			int b = sc.nextInt();
			int perimeter3 = 2*(l+b);
			System.out.println("Perimeter of a rectangle: "+perimeter3);
			break;
			
			default: System.out.println("Invalid Shape");
		}
	}
}
