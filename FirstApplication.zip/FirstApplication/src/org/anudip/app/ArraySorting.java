package org.anudip.app;

import java.util.*;

public class ArraySorting {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	/*int[] arr = {8,4,3,5,6};
	String[] str = {"C","O","I","P","U"};
	
	Arrays.sort(arr);
	Arrays.sort(str);
	
	System.out.println(Arrays.toString(arr));
	System.out.println(Arrays.toString(str));*/
	
	
	int[] arr = {10,7,9,13,17};
	String[] str = {"E","H","G","A","C"};
	
	Arrays.sort(arr);
	Arrays.sort(str);
	
	System.out.println(Arrays.toString(arr));
	System.out.println(Arrays.toString(str));
	}
}
