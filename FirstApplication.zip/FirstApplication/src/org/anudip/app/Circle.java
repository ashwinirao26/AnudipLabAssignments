package org.anudip.app;

import java.util.Scanner;

public class Circle {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Radious");
		int radious = sc.nextInt();
		double pi = 3.1416;
		
		double perimeter = 2*pi*radious;
		double area = pi*radious*radious;
		System.out.println("The perimeter is: "+perimeter);
		System.out.println("The area is: "+area);
	}
	
}
