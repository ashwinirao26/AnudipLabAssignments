package org.anudip.app;

import java.util.Scanner;

public class IncomeTaxCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		String name = sc.nextLine();
		System.out.println("Enter your salary");
		double annualIncome = sc.nextDouble();
		double incomeTax = 0;

		
		if(annualIncome<=250000) {
			incomeTax = 0.0;
		}
		else if(annualIncome<=500000) {
			incomeTax = (annualIncome-250000)*0.1;
		}
		else if(annualIncome<=1000000) {
			incomeTax = ((annualIncome-500000)*0.2)+30000;
		}
		else if(annualIncome>=1000001) {
			incomeTax = ((annualIncome-1000000)*0.3)+50000;
			}
		System.out.println(name+" you have to pay "+incomeTax);
	}
}
