package org.anudip.app;
import java.util.Scanner;

public class Fibonacci {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int num = sc.nextInt();
		int fib1 = 0;
        int fib2 = 1;
        int fib;
        System.out.print(fib1+" "+fib2);

        for (int i = 1; i <= num; i++) {
            fib = fib1+fib2;
            System.out.print(" "+fib);
            fib1 = fib2;
            fib2 = fib;
        }
	}
}
