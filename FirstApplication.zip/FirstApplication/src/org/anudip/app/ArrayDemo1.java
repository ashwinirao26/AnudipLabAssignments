package org.anudip.app;

import java.util.Scanner;

public class ArrayDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Size of the Array");
		int n = sc.nextInt(); // taking size of array from user
		int[] arr = new int[n]; // Initializing of array
		boolean flag = false;
		
		System.out.println("Enter Array Elements"+" ");
		for(int i=0;i<n;i++) {
			arr[i] = sc.nextInt();// loading array values
		}
		
		for(int temp: arr) {
			if(temp%2==0) { // Condition for checking even
				System.out.print(temp+" ");
				flag = true;
			} // end of if block
		}
			if(flag==false)
			{
				System.out.println("No even number found");
			}
	}
}
		
