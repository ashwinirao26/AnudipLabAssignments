package org.anudip.app;

import java.util.Scanner;

public class JavaApp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Id");
		int eId = sc.nextInt(); sc.nextLine(); // Integer.parseInt(sc.nextLine());
		System.out.println("Enter Employee Name");
		String eName = sc.nextLine();
		System.out.println("Enter employee Salary");
		double salary = sc.nextDouble();
		
		System.out.println("Employee Id: "+eId);
		System.out.println("Employee Name: "+eName);
		System.out.println("Employee Salary: "+salary);
		
		
	}

}
