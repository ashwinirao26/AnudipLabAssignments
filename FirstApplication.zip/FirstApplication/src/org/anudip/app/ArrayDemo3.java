package org.anudip.app;

import java.util.Scanner;

public class ArrayDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] arr = {2,3,4,5,6,7,8};
		System.out.println("Enter a Number you want to search");
		int n = sc.nextInt();
		boolean flag = false;
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i]==n) {
			System.out.println("The value present in the location: "+(i+1));
			flag = true;
			break;
			}
			}
		if(!flag) {
			System.out.println("Data not found in array");
		}
	}
}
