package org.anudip.app;
import java.util.Arrays;
import java.util.Scanner;

public class Rev {
		public static void main(String[] args) {
			//Accepting String
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter a String:");
			String input =scanner.nextLine().toUpperCase();
			//Function calling ad displaying output
			String result=collectSingleCharactersAssendingString(input);
			System.out.println(result);
			scanner.close();
		}//end of main
		
		//function for removing duplicate and sorting
		public static String collectSingleCharactersAssendingString(String input) {
			String result1= new String();
			//check if the character appears only once in the input string
			for(int i=0; i<input.length();i++) {
				char currentChar=input.charAt(i);
				if(input.indexOf(currentChar)==input.lastIndexOf(currentChar)) {
					result1+=currentChar;
				}
			}
			//sort the result1 String
			char[]charArr=result1.toCharArray();
			Arrays.sort(charArr);
			return new String(charArr);
		}
		

	}
