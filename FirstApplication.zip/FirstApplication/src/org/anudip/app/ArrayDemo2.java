package org.anudip.app;

import java.util.Scanner;

public class ArrayDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] arr = {{2,3,4,5},{5,6,7,8},{7,8,4,7}};
		for(int rows=0; rows<3; rows++) {
			System.out.println();
			for(int cols=0; cols<4; cols++) {
				System.out.print(arr[rows][cols]+" ");
			}
		}
	}
}
