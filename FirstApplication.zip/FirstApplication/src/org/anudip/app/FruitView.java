package org.anudip.app;
import flower.*;
public class FruitView {

	public static void main(String[] args) {
		Rose.show();
	}

}
