package org.anudip.app;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter First Number");
//		double num1  = sc.nextDouble();
//		System.out.println("Enter Second Number");
//		double num2  = sc.nextDouble();
//		System.out.println("Enter an Operator");
//		char op = sc.next().charAt(0);
//		double result;
//		
//		
//		switch(op) {
//		case'+':result = num1+num2;	
//				System.out.println(num1+" "+op+" "+num2+": "+result);
//				break;
//				
//		case'-':result = num1-num2;
//				System.out.println(num1+" "+op+" "+num2+": "+result);
//				break;
//				
//		case'*':result = num1*num2;	
//				System.out.println(num1+" "+op+" "+num2+": "+result);
//				break;
//		
//		case'/':result = num1/num2;
//				System.out.println(num1+" "+op+" "+num2+": "+result);
//				break;
//		default: 
//			System.out.println("Invalid Operator");
//				}

				 Scanner scanner=new Scanner(System.in);
				 System.out.println("Enter 1st operand:");
				 int operand1=Integer.parseInt(scanner.nextLine());
				 System.out.println("Enter 2nd operand:");
				 int operand2=Integer.parseInt(scanner.nextLine());
				 System.out.println("Enter Math operator:");
				 String operator=scanner.nextLine();
				 int result=0;
				 switch(operator) {
				 case "+" : result=operand1+operand2;break;
				 case "-" : result=operand1-operand2;break;
				 case "*" : result=operand1*operand2;break;
				 case "/" : result=operand1/operand2;break;
				 case "%" : result=operand1%operand2;break;
				 default : System.out.println("Wrong Math operator");
				  }
				 System.out.println("The result:"+result);
		   }
}
