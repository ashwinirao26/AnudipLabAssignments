package org.anudip.app;
import java.util.*;
public class main {
	public static void main(String[] args) {
		//Accepting input
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the PAN card ID: ");
		String panCardId = sc.nextLine();
		sc.close();
		//checking if length of ID is 10 or not if not then displaying Invalid
		if(panCardId.length()<10) {
			System.out.println("Invalid");
			return;
		} 
		//Function Calling and displaying output
		String formattedPanCardId = panCardValidation(panCardId);
        System.out.println("Output: " + formattedPanCardId);
	}// end of main method
	
	//method for validating PAN card ID
	public static String panCardValidation(String panCardId) {
		
		 if (!panCardId.matches("[A-Za-z0-9]{10}")) {
	            return "Invalid";
	        }
		 else if (panCardId.matches("[A-Za-z]+")) {
	            return "Invalid";
	        }
		 else if (panCardId.matches("[0-9]+")) {
	            return "Invalid";
	        }
		 for(int i=0;i<panCardId.length();i++) {
		  if(panCardId.charAt(i)>='a' && panCardId.charAt(i)<'z') {
			  return "Invalid PAN!! PAN Card ID should be in UpperCase Only";
		  }
		 }
		String formattedPanCardId = panCardId;
		
		char[] charArray = formattedPanCardId.toCharArray();
		char[] numbers = new char[4];
		char[] alphabets = new char[6];
		
		int indexOfnum = 0;
		int indexOfAlphabets = 0;
		for(char c: charArray) {
			if(Character.isDigit(c)) {
				numbers[indexOfnum++] = c;
			}
			else if(Character.isAlphabetic(c)) {
				alphabets[indexOfAlphabets++] = c;
		}
	}
		Arrays.sort(numbers);
		Arrays.sort(alphabets);
		reverseArray(alphabets);
		
		formattedPanCardId = new String(alphabets)+new String(numbers);
		return formattedPanCardId;
	
}
	public static void reverseArray(char[] arr) {
		int left = 0;
		int right = arr.length-1;
		while(left<right) {
			char temp = arr[left];
			arr[left] = arr[right];
			arr[right] = temp;
			left++;
			right--;
		}
	}
}
