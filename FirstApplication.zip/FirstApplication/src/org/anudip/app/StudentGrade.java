package org.anudip.app;

import java.util.Scanner;

public class StudentGrade {

	public static void main(String[] args) {
		/*write a java application that will accept marks percentage of a student. If percentage >89 assign grade "E", if percentage >74 assign grade "V"
		if percentage >59 assign grade "G", if percentage >=50 assign grade "P" else assign grade "F".*/
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Percentage");
		int percentage = sc.nextInt();
		if(percentage>89) {
			System.out.println("Grade E");
		}
		else if(percentage>74) {
			System.out.println("Grade V");
		}
		else if(percentage>59) {
			System.out.println("Grade G");
		}
		else if(percentage>=50) {
			System.out.println("Grade P");
		}
		else {
			System.out.println("Grade F");
		}
	}
}
