package org.anudip.app;

import java.util.Scanner;

public class CelsiusToFahrenheit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Celsius Value");
		double celsius = sc.nextDouble();
		double fehrenheit = (9.0/5.0)*celsius + 32;
		System.out.println(fehrenheit);
	}

}
