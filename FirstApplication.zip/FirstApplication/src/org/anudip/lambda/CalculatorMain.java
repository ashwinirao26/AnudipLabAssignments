package org.anudip.lambda;
import java.util.Scanner;
public class CalculatorMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		CalculatorFace cf = (x,y,op)->{
			int result = 0;
			switch(op) {
			case "+" : result= x+y; break;
			case "-" : result= x-y; break;
			case "*" : result= x*y; break;
			case "/" : result= x/y; break;
			case "%" : result= x%y; break;
			default: result=0;
			}
			return result;
		};
		System.out.println("Enter 1st operand:");
		int i = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter 2nd operand:");
		int j = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Math operator:");
		String op = scanner.nextLine();
		int r=cf.calculate(i, j, op);
		System.out.println("The Result:"+r);
	}
}
