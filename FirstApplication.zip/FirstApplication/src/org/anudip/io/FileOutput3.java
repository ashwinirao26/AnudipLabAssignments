package org.anudip.io;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileOutput3 {
	public static void main(String[] args) throws IOException{
		Scanner scanner = new Scanner(System.in);
		//FileWriter object points to number.txt in write mode
		FileWriter fileWriter = new FileWriter("d:/number.txt",true);
		//BufferedWriter will write inside the file which fileWriter is pointing to i.e number.txt
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		//accept data from user
		System.out.print("Enter a number: ");
		char[] numbers = new char[9];
		for(int i=0; i<=9; i++) {
			numbers[i] = scanner.next().charAt(0);
		}
		//BufferedWriter transfer to content to the file
		bufferedWriter.write(numbers);
		bufferedWriter.flush();
		bufferedWriter.newLine();
		bufferedWriter.close();
		fileWriter.close();
		scanner.close();
		System.out.println("File Written");
		}
	}
