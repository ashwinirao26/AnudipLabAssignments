package org.anudip.assignment;
import java.util.Scanner;
/*Write a Program that will accept size of array . If the size is negative or less than 3
then it will display message "Invalid Input". Input into the array. If Any input is 0 or negative then 
also display message "Invalid Input". Find the sum of  highest & lowest inputs.*/

public class SumOfHighestLowestValue {
	public static void main(String[] args) {
		//Taking input 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the Array: ");
		int n = sc.nextInt(); //size of the array
		if(n<3) {
			System.out.println("Invalid Input");
		}
		int[] arr = new int[n];
		System.out.println("Enter arrays element");
		//loading array values and checking if any elements are 0 or not if 0 then printing invalid input
		for(int i=0; i<n; i++) {
			int input = sc.nextInt();
			if(input<=0) 
				System.out.println("Invalid Input");
				arr[i] = input;
		}
		sc.close();
		//finding highest and lowest values and adding into sum
		int highestVal=arr[0],lowestVal=arr[0];
		for(int i=1; i<n; i++) {
			if(arr[i]>highestVal) {
				highestVal =  arr[i];
			}
			if(arr[i]<lowestVal) {
				lowestVal =  arr[i];
			}
		}
			int sum = highestVal + lowestVal;
			System.out.println("Sum of highest and lowest values are: "+sum);
	}
}

