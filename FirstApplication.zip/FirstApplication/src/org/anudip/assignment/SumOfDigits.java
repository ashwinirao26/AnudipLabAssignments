package org.anudip.assignment;
import java.util.Scanner;

/*Write a Java program that will accept a number which has at least 10 digits. You need to add the digits .
If the result is a single digit figure then show the result else you need add the digits of result again 
and continue the process until a single digit output is found.*/

public class SumOfDigits {
	public static void main(String[] args) {
		//Taking input 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		String num = sc.nextLine(); //taking input in string type because we've to check if it is 10 digits or not
		sc.close();
		// checking if input is less than 10 digits or not
		if(num.length()<10) {
			System.out.println("Enter atleast 10 digits");
			return;
		}
		//function calling
		int sumOfDigits = calculateSumOfDigits(num);
		// Here Continuing the process until a single-digit output is found
		 while (sumOfDigits > 9) {
	            sumOfDigits =calculateSumOfDigits(Integer.toString(sumOfDigits));
	        }
		 System.out.println("The sum of digits of a number till single digit are: "+sumOfDigits);	
		 }// end of main method
	
		//Method for sum of digits
		public static int calculateSumOfDigits(String num) {
			int sum = 0;
	        for (int i = 0; i < num.length(); i++) {
	            int digit = Character.getNumericValue(num.charAt(i));
	            sum += digit;
	        }

	        return sum;
	}// end of method
}// end of a class
