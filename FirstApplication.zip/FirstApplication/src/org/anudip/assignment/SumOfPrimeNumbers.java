package org.anudip.assignment;
import java.util.Scanner;
/*Q4. Write a Program that will accept size of array . If the size is negetive  then it will display message
"Invalid Input". Input into the array.Find the sum of  prime numbers present into that array.If no prime
number is present then display message "No".*/
public class SumOfPrimeNumbers {

	public static void main(String[] args) {
		//Taking input 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the Array: ");
		int n = sc.nextInt(); //size of the array
		if(n<0) {
			System.out.println("Invalid Input");
		}
		int[] arr = new int[n];
		System.out.println("Enter arrays element");
		for(int i=0; i<n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int sumOfPrimeNo = calculateSum(arr);
		if(sumOfPrimeNo==0) {
			System.out.println("No");
		}
		else {
			System.out.println("The sum of prime numbers are: "+sumOfPrimeNo);
		}
	}
	public static int calculateSum(int[] arr) {
		int sum = 0;
		for(int number:arr) {
		if(isPrime(number)) {
		sum = sum + number;
		}
		}
		return sum;
	}
	public static boolean isPrime(int number) {
		if(number<=1) {
			return false;
		}
		for(int i=2; i<number/2;i++) {
			if(number%i==0) {
				return false;
			}
		}
		return true;
	}
}
