package org.anudip.assignment;
import java.util.Scanner;
/* Wap that will accept a string and collect all single characters and store them in ascending order in 
a 2nd string.
 input: SUCCESSERIE
  output:IRU*/

public class StringAscendingOrder {
	    public static void main(String[] args) {
	        //Accepting input 
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a string: ");
	        String input = sc.nextLine().toUpperCase();
	        
	        //Function Calling and displaying output
	        String result = collectSingleCharacters(input);
	        System.out.println("Output: " + result);
	        sc.close();
	    }// end of main method
	    
	    //Method for removing duplicates and sorting 
	    public static String collectSingleCharacters(String input) {
	        StringBuilder result = new StringBuilder();
	        // Convert the input string to uppercase to make it case-insensitive
	        input = input.toUpperCase();
	        for (int i = 0; i < input.length(); i++) {
	            char currentChar = input.charAt(i);
	            // Check if the character appears only once in the input string
	            if (input.indexOf(currentChar) == input.lastIndexOf(currentChar)) {
	                // Check if the character is not already in the result string
	                if (result.indexOf(Character.toString(currentChar)) == -1) {
	                    result.append(currentChar);
	                }
	            }
	        }
	        // Sort the result string in ascending order
	        char[] charArray = result.toString().toCharArray();
	        java.util.Arrays.sort(charArray);
	        return new String(charArray);
	    }
	}

