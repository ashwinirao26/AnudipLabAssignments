package org.anudip.assignment;
import java.util.Scanner;

/* Create a Java static  function extractSubString(String myString,int cutPoint,int numbersOfCharacters)
 in class Main. The return type of the function is String.
Ex1.
Input: extractSubString(“venkataraghavan”,6,5)
Outout:tarag */

public class SubString {
	public static void main(String[] args) {
		//Taking input
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String value: ");
		String myString = sc.nextLine();
		System.out.println("Enter cut point: ");
		int cutPoint = sc.nextInt();
		cutPoint--;
		System.out.println("Enter the number of character you want to extract: ");
		int numbersOfCharacters = sc.nextInt();
		sc.close();
		numbersOfCharacters=numbersOfCharacters+cutPoint;
		
		//Function calling and printing
		String extractedSubString =  extractSubString(myString,cutPoint,numbersOfCharacters);
		System.out.println("The extracted SubString is: "+extractedSubString);
	}// end of main class
	
	//Method for finding substring
	public static String extractSubString(String myString,int cutPoint,int numbersOfCharacters) {
		String myStr = myString.substring(cutPoint,numbersOfCharacters);
		return myStr;
	}// end of method/function
}
