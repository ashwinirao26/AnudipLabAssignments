package org.anudip.regex;
import java.util.regex.*;

public class RegexDemo1 {

	public static void main(String[] args) {
		Pattern p1 = Pattern.compile(".s");
		String s1 = "is";
		Matcher m1 = p1.matcher(s1);
		System.out.println(m1.matches());
		
		Pattern p2 = Pattern.compile("..s");
		String s2 = "tis";
		Matcher m2 = p2.matcher(s2);
		System.out.println(m2.matches());
	}
}
