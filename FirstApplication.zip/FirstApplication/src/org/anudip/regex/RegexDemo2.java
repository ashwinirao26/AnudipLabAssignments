package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo2 {

	public static void main(String[] args) {
		// Write Java application that will accept a name with Mr or Mrs or Ms.
		// If these are not present,naming will be not consider properly.
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a name");
        String name = sc.nextLine();
        sc.close();
		Pattern p1 = Pattern.compile("[Mr|Mrs|Ms]+[A-Za-z.' ']+$");
		Matcher m1 = p1.matcher(name);
		 if (m1.matches()) {
	            System.out.println("It is a valid name");
	        } else {
	            System.out.println("Invalid name");
	        }
	}
}
