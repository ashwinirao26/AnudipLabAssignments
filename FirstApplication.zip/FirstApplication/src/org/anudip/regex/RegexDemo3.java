package org.anudip.regex;
import java.util.*;
public class RegexDemo3 {

	public static void main(String[] args) {
		//Write a java application that will accept an email id and check that whether it is gmail or not.
				Scanner sc = new Scanner(System.in);
		        System.out.print("Enter an email address: ");
		        String email = sc.nextLine();
		        sc.close();

		        boolean isGmail = checkIfGmail(email);
		        if (isGmail) {
		            System.out.println("It is a valid gmail");
		        } else {
		            System.out.println("Invalid Gmail address");
		        }
		    }

		    private static boolean checkIfGmail(String email) {
		        String domain = email.substring(email.indexOf('@') + 1);
		        return domain.equalsIgnoreCase("gmail.com");
		    }
	}
