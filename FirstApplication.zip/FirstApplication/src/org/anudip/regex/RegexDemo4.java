package org.anudip.regex;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your email");
		String email = sc.nextLine();
		sc.close();
		
		Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b");

        // Create a matcher with the input string
        Matcher matcher = pattern.matcher(email);

        // Find all matches
        while (matcher.find()) {
            String match = matcher.group();
            System.out.println("Match found: " + match);
        }

	}

}
