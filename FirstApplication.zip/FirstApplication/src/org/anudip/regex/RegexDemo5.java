package org.anudip.regex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Write a Java applicaton that will accept your date of joining in office in dd-mm-yyyy format. Use Java Regex.
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a date");
		String email = sc.nextLine(); //taking input from user
		Pattern pattern = Pattern.compile("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$"); //logic for date 
		Matcher matcher = pattern.matcher(email);
		
		//checking condition and printing
		if (matcher.matches()) {
            System.out.println("It is a valid joining date");
        } else {
            System.out.println("Invalid joining date");
        }
	}

}
