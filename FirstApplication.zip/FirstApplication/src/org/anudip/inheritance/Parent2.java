package org.anudip.inheritance;

public class Parent2 {
	private int i;
	public Parent2(){
		i=10;
		System.out.println("Parent Constructor");
	}
	public void show() {
		System.out.println("The value of i is: "+i);
	}
}
