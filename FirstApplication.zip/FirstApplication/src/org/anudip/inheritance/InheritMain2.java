package org.anudip.inheritance;

public class InheritMain2 {
	public static void main(String[] args) {
	Child ch = new Child();
	ch.show();
	}
}
