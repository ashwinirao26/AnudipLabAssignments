package org.anudip.inheritance;

public class Person {
	//data member
	private String name;
	private int age;
	
	public Person() {
		name = "Ron";
		age = 25;
	}
	public void speak() {
		System.out.print("Hey everyone my name is "+name+" "+"my age is "+age);
	}
}
