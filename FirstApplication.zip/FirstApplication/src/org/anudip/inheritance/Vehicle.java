package org.anudip.inheritance;

public class Vehicle {
	private String brand;
	private String model;
	private int year;
	
	public Vehicle() {
		brand = "TATA";
		model = "TATA Nexon";
		year = 2023;
	}
	public void drive() {
		System.out.print("Hello i am driving the "+model+" brand of "+brand+" "+year+" ");
	}
}
