package org.anudip.inheritance;

public class Student extends Person{
	private String grade;
	
	public Student() {
		grade = "A";
	}
	public void study() {
		System.out.print(" and my Grade is "+grade);
	}
}
