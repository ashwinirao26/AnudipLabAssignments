package org.anudip.inheritance;

public class VehicleMain {
	public static void main(String[] args) {
		Car myCar = new Car();
		myCar.drive();
		myCar.honk();
	}
}
