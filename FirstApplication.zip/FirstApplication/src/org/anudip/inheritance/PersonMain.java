package org.anudip.inheritance;

public class PersonMain {

	public static void main(String[] args) {
		Student student = new Student();
		student.speak();
		student.study();
	}
}
