package org.anudip.inheritance;

public class Car extends Vehicle{
	private String colour;
	
	public Car() {
		colour = "Blue";
	}

	public void honk() {
		System.out.print("and the colour is "+colour);
	}
}
