package org.anudip.bean;
import java.util.Scanner;
import org.anudip.bean.Product;
import org.anudip.bean.ProductService;

public class ProductMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter details (productId,productName,purchasePrice) format : ");
		String input = sc.nextLine();
		String[] inputArray = input.split(",");
		int productId=Integer.parseInt(inputArray[0]);
		String productName = sc.nextLine();
		double purchasePrice = Double.parseDouble(inputArray[3]);
		Product product = new Product(productId,inputArray[1],purchasePrice);
		double salesPrice=ProductService.calculateSalesPrice(product);
		product.setSalesPrice(salesPrice);
		System.out.println(salesPrice);
	}
}
