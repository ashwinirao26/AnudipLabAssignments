package org.anudip.bean;
import org.anudip.bean.Product;
public class ProductService {
	public static double calculateSalesPrice(Product product) {
		double salesPrice = product.getPurchasePrice()+product.getPurchasePrice()*0.1;
		return salesPrice;
	}

}
