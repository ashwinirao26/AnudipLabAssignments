package org.anudip.bean;

public class Demo {
	private int i;
	private double j;
	public Demo() {
		i=0;
		j=0.0;
		System.out.println("Non Para constructor");
	}
	public void display() {
		System.out.println("The valur of i:"+i);
		System.out.println("The valur of j:"+j);
	}
}
