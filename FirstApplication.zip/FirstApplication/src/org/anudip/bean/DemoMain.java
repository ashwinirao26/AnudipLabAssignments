package org.anudip.bean;

public class DemoMain {

	public static void main(String[] args) {
		

	}

}
