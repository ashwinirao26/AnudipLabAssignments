package org.anudip.bean;

public class Product {
	Integer productId;
	String productName;
	Double purchasePrice;
	Double salesPrice;
	public Product(Integer productId, String productName, Double purchasePrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.purchasePrice = purchasePrice;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(Double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public Double getSalesPrice() {
		return salesPrice;
	}
	public void setSalesPrice(Double salesPrice) {
		this.salesPrice = salesPrice;
	}
	@Override
	public String toString() {
		String output= String.format("%-5s %-10s %-10s %-10s %-5s",productId,productName,purchasePrice,salesPrice);
		return  output;
	}
}
