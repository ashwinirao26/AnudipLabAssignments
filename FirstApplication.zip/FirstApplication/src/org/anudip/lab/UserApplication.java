package org.anudip.lab;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
public class UserApplication {
	//Attributes
	private static List<User> userList=new ArrayList<>();
	private static BufferedReader br=null;
	//Place all users into a List from File
	public static void uploadToList(String fileName)throws IOException{ 
		try {
			br= new BufferedReader(new FileReader(fileName));
			String line;
			while((line=br.readLine())!=null){
				String[] userData =line.split(",");
				User user=new User();
				user.setUserId(userData[0].trim());
				user.setPassword(userData[1].trim());
				userList.add(user);
				}//end of while
			}//end of try block
		catch(IOException e) {
			e.printStackTrace();
		}//end of catch block
		finally {
			if(br!=null) {
				br.close();
			}
		}//end of finally block	
	}//end of static function
	public static void main(String[] args)throws IOException {
		String fileName="d:/UserMaster.txt";
		Scanner scanner =new Scanner(System.in);
		//Taking data inside a text file
		FileWriter fileWriter =new FileWriter(fileName);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
  
		while(true) {
			String input = scanner.nextLine();
			//write done to stop taking data 
			if("done".equalsIgnoreCase(input.trim())) {
				break;
			}
			bufferedWriter.write(input);
			bufferedWriter.flush();
			bufferedWriter.newLine();
			}
          	bufferedWriter.close();
          	fileWriter.close();
          	//Called uploadToList function
          	uploadToList(fileName);

          	//Accept User-Id and Password from user
          	System.out.println("Enter User Id:");
          	String Id=scanner.nextLine();
          	System.out.println("Enter Password:");
          	String Password=scanner.nextLine();
          	//Check userId is valid and corresponding password
          	Iterator<User> itr=userList.iterator();
          	while(itr.hasNext()) {
          		User u =itr.next();
          		if((u.getUserId().equals(Id))){
          			if(u.getPassword().equals(Password)) {
          				System.out.println("Valid User");
          				break;
          			}else {
          				System.out.println("Invalid User");
          				break;
          			}
          		}
          	}//end of while-loop 
          	scanner.close();
	}//end of main
}//end of class
