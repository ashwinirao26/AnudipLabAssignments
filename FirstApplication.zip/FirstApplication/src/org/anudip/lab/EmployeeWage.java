package org.anudip.lab;
import java.util.Scanner;

public class EmployeeWage {
	//Member function for formatting value into two decimal place values
	public static String convertToTwoDecimalPlace(double value) {
		 return String.format("%.2f", value);
	}
	//Main method
	public static void main(String[] args) {
		//Accepting input
		Scanner scanner = new Scanner(System.in);
		double totalWage = 0.0;
		System.out.print("Enter the number of workers: ");
	    int numOfWorkers = Integer.parseInt(scanner.nextLine());
	    if(numOfWorkers<5) {
	    	System.out.println("Wrong workers number");
	    	return;
	    }
	  //creating wage array 
	  		double []wageArr=new double[numOfWorkers];
	  		//Accept each worker wages
	  		System.out.println("Enter wages of all workers");
	  		for(int i=0; i<wageArr.length;i++) {
	  			try {
	  			System.out.print("The wage of worker "+(i+1)+": ");
	  			wageArr[i]=Double.parseDouble(scanner.nextLine());
	  			if(wageArr[i]<100.00 || wageArr[i]>250.00) {
	  				i--;
	  				throw new WageException("Invalid wage");
	  			}
	  		}//end of try
	  		catch(WageException we) {
	  			System.out.println("WageException : "+we.getMessage());
	  			System.out.println("Re-enter a valid wage value");
	  		}//end of catch
	  		}//end of loop
	  		//calculate total wage and average wage
	  		for(int i=0; i<wageArr.length;i++) {
	  			totalWage+=wageArr[i];
	  		}
	  		double averageWage=(double)totalWage/wageArr.length;
	  		//Displaying output
	    System.out.println("Total wage for the site: " + convertToTwoDecimalPlace(totalWage));
        System.out.println("Average wage for the site: " + convertToTwoDecimalPlace(averageWage));
     scanner.close();
	}//end of main 
	}//end of class
