package org.anudip.lab;
import java.util.Scanner;

public class ShowRoom {
	//Data Members
	private String customerName;
	private long customerMobNo;
	private double cost;
	private double dis;
	private double amount;
	//Default Constructor(Member Method)
	public ShowRoom() {
		customerName = "";
		customerMobNo= 0;
		cost = 0.0;
		dis = 0.0;
		amount = 0.0;
	}
	//Method to input customer details(Member Method)
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Name: ");
		customerName = sc.nextLine();
		System.out.println("Enter Customer Mobile Number: ");
		customerMobNo = sc.nextLong();
		System.out.println("Enter Cost: ");
		cost = sc.nextDouble();
		sc.close();
	}
	//Method to Calculating discount(Member Method)
	void calculate() {
		if(cost<=10000) 
			dis = 0.05*cost;
		else if(cost>10000 && cost<=20000) 
			dis = 0.10*cost;
		else if(cost>20000 && cost<=35000) 
			dis = 0.15*cost;
		else 
			dis = 0.20*cost;
		amount = cost - dis;
		}
	//Method to displaying customer details and amount to be paid after discount
	void display() {
		System.out.println("Customer Name: "+customerName);
		System.out.println("Customer Mobile Number: "+customerMobNo);
		System.out.println("Total Amount to be paid after discount: "+amount);
	}
	//Main Method
	public static void main(String[] args) {
		//Object creation and calling
		ShowRoom showroom = new ShowRoom();
		showroom.input();
		showroom.calculate();
		showroom.display();
	}//end of main method
}//end of class

