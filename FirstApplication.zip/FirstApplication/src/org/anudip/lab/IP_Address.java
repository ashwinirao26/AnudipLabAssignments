package org.anudip.lab;
import java.util.Scanner;

public class IP_Address {
	public static void main(String[] args) {
		//Accepting input
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter IP Address: ");
		String ipAddress = sc.nextLine();
		//Range 0 to 255
		String digitRegex = "(\\d{1,2}|(0|1)\\d{2}|2[0-4]\\d|25[0-5])";
		
		//Check if it is valid or not and displaying output
		if(ipAddress.matches(digitRegex + "\\."+digitRegex + "\\."+digitRegex + "\\."+digitRegex)){
			System.out.println("Valid");
		}
		else {
			System.out.println("Invalid");
		}
		sc.close();
		}//end of main method
}//end of class
