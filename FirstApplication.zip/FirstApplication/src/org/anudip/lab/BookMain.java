package org.anudip.lab;
import java.util.List;
import java.util.Scanner;

public class BookMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		  BookService bookService = new BookService();
	        List<Book> books = Library.getAllBooks();
	        //Displaying book name book title and author name accordingly
	        while (true) {
	            System.out.println("Menu");
	            System.out.println("1. Display Book Number-wise");
	            System.out.println("2. Display Book Title-wise");
	            System.out.println("3. Display Book Author-wise");
	            System.out.println("4. Exit");
	            System.out.print("Enter choice(1-4): ");

	            int choice = Integer.parseInt(scanner.nextLine());

	            if (choice == 4) {
	                System.out.println("Exiting the program.");
	                break;
	            }
	            switch (choice) {
	                case 1:
	                    books = bookService.arrangeBooksNumberWise(books);
	                    break;
	                case 2:
	                    books = bookService.arrangeBooksTitleWise(books);
	                    break;
	                case 3:
	                    books = bookService.arrangeBooksAuthorWise(books);
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please select a valid option.");
	            }
	            System.out.println(String.format("%-10s %-35s %-20s","BookNumber","Book Title","Author"));
	            System.out.println("----------------------------------------------------------");
	            for (Book book : books) {
	                System.out.println(book);
	            }
	        }//end of loop
	        scanner.close();
	}//end of main
}//end of class
