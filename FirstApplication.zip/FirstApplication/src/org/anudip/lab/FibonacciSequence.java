package org.anudip.lab;

import java.util.Scanner;

public class FibonacciSequence {
	public static void main(String[] args) {
		//Taking input number from user for checking if it is in fibonacci sequence or not
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int num = sc.nextInt();
		sc.close();
		int fib1 = 0; //First term
        int fib2 = 1; //Second term
        int fib3 = 0; //Rest terms
        //logic for finding fibonacci sequence
        while(fib3<num) {
            fib3 = fib1+fib2;
            fib1 = fib2;
            fib2 = fib3;
        }//end of while loop
        //Checking if the input number is in fibonacci sequence or not and printing yes or no according to that
        if(fib3==num) {
        	System.out.println("yes");
        }
        else {
        	System.out.println("no");
        }
	}
}
