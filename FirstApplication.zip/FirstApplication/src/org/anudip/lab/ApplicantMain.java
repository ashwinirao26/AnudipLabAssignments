package org.anudip.lab;
import java.util.Scanner;

public class ApplicantMain {
	public static void main(String[] args) {
		//Accepting input 
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number of Applicants: ");
		int numberOfApplicants = scanner.nextInt();//size of the array
		scanner.nextLine(); // Consume the newline character
		Applicant[] applicants = new Applicant[numberOfApplicants];
		//accepting consumer’s details in a comma(,) separated 
		for(int i = 0; i < numberOfApplicants; i++) {
            System.out.print("Enter applicant details "+ (i + 1) + ": "+"(Name, Subject1, Subject2, Subject3): ");
            String input = scanner.nextLine();
            String[] details = input.split(",");
            String name = details[0];
            int subject1 = Integer.parseInt(details[1]);
            int subject2 = Integer.parseInt(details[2]);
            int subject3 = Integer.parseInt(details[3]);
            
            //Checking if any subject's marks is less than 0 or more than 100 if yes then printing error
            if (subject1 < 0 || subject1 > 100 || subject2 < 0 || subject2 > 100 || subject3 < 0 || subject3 > 100) {
                System.out.println("Error: Invalid marks! Marks should be between 0 and 100.");
                i--; // Retry the current iteration to enter valid data
                continue;
            }//end of if
            applicants[i] = new Applicant(name, subject1, subject2, subject3);
        }//end of loop

        // Displaying passed applicant's details
        System.out.println("\nPassed Applicants:");
        System.out.println("===========================================");
        System.out.println(String.format("%-10s %-5s %-5s %-5s %-10s %-10s", "Name", "Sub1", "Sub2", "Sub3", "Total", "Percentage"));
        System.out.println("===========================================");
        for (Applicant applicant : applicants) {
            if (applicant.getTotal() >= 210) { // 70% of 300 is 210
                System.out.println(applicant);
            }
        }//end of for loop
        scanner.close();
    }//end of main
}//end of class
