package org.anudip.lab;
//Applicant Class
public class Applicant {
	//member data
	private String name;
	private Integer subject1;
	private Integer subject2;
	private Integer subject3;
	private Integer total;
	private Integer percentage;
	//Constructor
	public Applicant(String name, Integer subject1, Integer subject2, Integer subject3) {
		super();
		this.name = name;
		this.subject1 = subject1;
		this.subject2 = subject2;
		this.subject3 = subject3;
		this.total = totalCalculation();
		this.percentage = percentageCalculation(this.total);
	}
	//Getter Setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getSubject1() {
		return subject1;
	}
	public void setSubject1(Integer subject1) {
		this.subject1 = subject1;
	}
	public Integer getSubject2() {
		return subject2;
	}
	public void setSubject2(Integer subject2) {
		this.subject2 = subject2;
	}
	public Integer getSubject3() {
		return subject3;
	}
	public void setSubject3(Integer subject3) {
		this.subject3 = subject3;
	}
	public Integer getTotal() {
        return total;
    }

    public Integer getPercentage() {
        return percentage;
    }
    // Method to calculate total marks
    public int totalCalculation() {
        if (subject1 < 50 || subject2 < 50 || subject3 < 50) {
            return 0;
        }
        return subject1 + subject2 + subject3;
    }

    // Method to calculate percentage
    public int percentageCalculation(int total) {
        return (int) ((total / 300.0) * 100);
    }
	//To String 
	@Override
	public String toString() {
		String output= String.format("%-10s %-5s %-5s %-5s %-10s %-10s",name,subject1,subject2,subject3,total,percentage);
		return output;
		}
}
