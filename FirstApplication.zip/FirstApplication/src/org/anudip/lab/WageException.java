package org.anudip.lab;

public class WageException extends RuntimeException {
	static final long serialVersionUID = 1L;
	public WageException(String message) {
        super(message);
        }
	}
