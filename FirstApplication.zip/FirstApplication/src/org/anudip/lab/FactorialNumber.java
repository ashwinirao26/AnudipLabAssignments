package org.anudip.lab;
import java.util.Scanner;

public class FactorialNumber {
	public static void main(String[] args) {
		//Accepting input
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int n = scanner.nextInt();
		//function calling and  printing
		if (isFactorialNumber(n)) 
			System.out.println("Yes");
		else
			System.out.println("No");
		scanner.close();
	}//end of main
	
	//method for checking factorial or not
	public static boolean isFactorialNumber(int n) {
		int factorial = 1;
		int i = 1;
		while (factorial < n) {
			i++;
			factorial *= i;
			}
		return factorial == n;
		}
	}//end of class
