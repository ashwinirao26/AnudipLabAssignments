package org.anudip.lab;
import java.util.*;


public class Anagram {
	public static void main(String[] args) {
		//Taking String Input From User
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first string");
		String string1 = sc.nextLine();
		System.out.println("Enter second string");
		String string2 = sc.nextLine();
		sc.close();
		
		//Function Calling and checking if the strings are anagram or not & printing
		if(checkAnagram(string1,string2)) {
			System.out.println("Anagram");
		}
		else {
			System.out.println("Not Anagram");
		}
	}//end of main method
	
	// Method for Checking both strings are Anagram or not. This will return true if it is anagram else false
	public static boolean checkAnagram(String string1,String string2) {
		//Replacing all the blank white space of both strings and Converting into lowercase
		string1 = string1.replaceAll("\\s", "").toLowerCase();
		string2 = string2.replaceAll("\\s", "").toLowerCase();
		
		//Checking if the length of string1 is equal to the length of string2 or not
		//If it is not equal then directly returns false and if true then it will go to else part
		if(string1.length()!=string2.length()) {
			return false;
		}//end of if block
		else {
			// converting strings into char arrays 
			char[] c1 = string1.toCharArray();
			char[] c2 = string2.toCharArray();
			
			//Sorting both char arrays
			Arrays.sort(c1);
			Arrays.sort(c2);
			//Here checking if string1 and string2 are equals or not, If equal return true
			return Arrays.equals(c1, c2);
		}
		//end of else block
	}
	//end of the method
}
