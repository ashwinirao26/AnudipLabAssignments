package org.anudip.lab;
import java.util.Scanner;
public class BillMain {
		public static void main(String[] args) {
			//Accepting input 
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter the number of Consumers: ");
			int numberOfConsumer = scanner.nextInt();//size of the array
			if(numberOfConsumer<=0) {
				System.out.println("Invalid Input");
				return;
			}
			//Array of consumer
			Consumer[] consumers = new Consumer[numberOfConsumer];
			//accepting consumer’s details in a comma(,) separated 
			for(int i=0; i<numberOfConsumer; i++) {
				scanner.nextLine(); // Consume the newline character left by nextInt()
			    System.out.print("Enter details of consumer number " + (i + 1) + ": ");
			    String consumerData = scanner.next();
			    String[] dataParts = consumerData.split(",");
			    if(dataParts.length != 3) {
			    	System.out.println("Invalid input for consumer " + (i + 1));
			    	return;
			    	}
			    String id = dataParts[0].trim();
			    String name = dataParts[1].trim();
			    int unitConsumed = Integer.parseInt(dataParts[2].trim());
			    consumers[i] = new Consumer(id, name, unitConsumed);
			    String finalPayment = BillService.billCalculation(consumers[i]);
			    consumers[i].setFinalPayment(finalPayment);
			    }//end of loop
				//displaying output
			    System.out.println("\nConsumer Details:");
			    System.out.println("=================");
			    System.out.println(String.format("%-5s %-20s %-10s %-10s", "ID", "Name", "Unit", "Payment"));
			    System.out.println("-------------------------------------------------");
			    for (Consumer consumer : consumers) {
			            System.out.println(consumer);
			        }//end of loop
			    scanner.close();
			    }//end of main method
			}//end of class
