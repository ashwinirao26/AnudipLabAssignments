package org.anudip.lab;
//Grade Mismatch Exception class
public class GradeMismatchException extends RuntimeException{
	static final long serialVersionUID = 3L;
	public GradeMismatchException(String message) {
        super(message);
        }
	}