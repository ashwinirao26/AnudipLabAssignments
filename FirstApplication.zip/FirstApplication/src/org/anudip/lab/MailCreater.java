package org.anudip.lab;
import java.util.Scanner;

public class MailCreater {
	public static void main(String[] args) {
		//Taking String Input From User
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Name");
		String studentName = sc.nextLine();
		//Function Calling
		String result = createMailAccount(studentName);
		//Printing 
		System.out.println(result+"@tsr.edu");
		sc.close();
	}
	//Method for creating mail account
	public static String createMailAccount(String studentName) {
		//Converting name into lowercase
		studentName = studentName.toLowerCase();
		//Replacing all the blank white space into "." 
		String mailID = studentName.replace(' ', '.');
		// returning the string 
		return mailID;
	}
}
