package org.anudip.lab;
//Contract Employee Class
public class ContractEmployee extends Employee {
	//Member Data
	private Integer contractPeriod;
	private Double contractAmount;
	private Double tax;
	private static int idGenerator=1001;
	// Static method to generate unique employee IDs
    public static int generatedId() {
        return idGenerator++;
    }
    //Constructors
    public ContractEmployee(String employeeId, String employeeName, String department,Integer contractPeriod, Double contractAmount) {
    	super(employeeId, employeeName, department);
    	this.contractPeriod = contractPeriod;
    	this.contractAmount = contractAmount;
    	this.tax=this.calculateTax();
    	}
    //Getter and setter
    public Integer getContractPeriod() {
    	return contractPeriod;
    }
    public void setContractPeriod(Integer contractPeriod) {
    	this.contractPeriod = contractPeriod;
    }
    public Double getContractAmout() {
    	return contractAmount;
    }
    public void setContractAmout(Double contractAmount) {
    	this.contractAmount = contractAmount;
    }
    public Double getTax() {
    	return tax;
    }
    public void setTax(Double tax) {
    	this.tax = tax;
    }
    public static int getIdGenerator() {
    	return idGenerator;
    }
    public static void setIdGenerator(int idGenerator) {
    	ContractEmployee.idGenerator = idGenerator;
    }
    //Implementing tax Calculation method
    	@Override
    	public double calculateTax() {
    	double empTax=(contractAmount/contractPeriod)*0.10;
    	return empTax;
    	}
    	//To String
    	@Override
    	public String toString() {
    		 return String.format("%-10s %-20s %-15s %-10s %-10s %-10s",
                     getEmployeeId(), getEmployeeName(), getDepartment(),
                     contractPeriod, contractAmount,tax);
    	}
}