package org.anudip.lab;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
//Book Service class
public class BookService {
		//To arrange books in ascending order of book number,book title,author's name.
		public List<Book> arrangeBooksNumberWise(List<Book> bookList){
	        Collections.sort(bookList, Comparator.comparing(Book::getBookNumber));
	        return bookList;
	    }

	    public List<Book> arrangeBooksTitleWise(List<Book> bookList) {
	        Collections.sort(bookList, Comparator.comparing(Book::getBookTitle));
	        return bookList;
	    }

	    public List<Book> arrangeBooksAuthorWise(List<Book> bookList) {
	        Collections.sort(bookList, Comparator.comparing(Book::getAuthor));
	        return bookList;
	    }
}
