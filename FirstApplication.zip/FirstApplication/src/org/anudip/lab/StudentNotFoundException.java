package org.anudip.lab;
// Exception class
public class StudentNotFoundException extends RuntimeException{
	static final long serialVersionUID = 1L;
	public StudentNotFoundException(String message) {
		super(message);
		}
}
