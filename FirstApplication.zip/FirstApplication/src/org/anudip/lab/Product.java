package org.anudip.lab;
//Product class
public class Product {
	//Member data
	private Integer id;
	private String name;
	private Double purchasedPrice;
	private Double salesPrice;
	private String grade;
	//Getter and setter
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPurchasedPrice() {
		return purchasedPrice;
	}
	public void setPurchasedPrice(Double purchasedPrice) {
		this.purchasedPrice = purchasedPrice;
	}
	public Double getSalesPrice() {
		return salesPrice;
	}
	public void setSalesPrice(Double salesPrice) {
		this.salesPrice = salesPrice;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	//To String method
	@Override
	public String toString() {
		String output= String.format("%-5s %-20s %-10s %-10s %-5s",id,name,purchasedPrice,salesPrice,grade);
		return output;
		}
}
