package org.anudip.lab;
public class StudentResult {
	//member data
	private String rollNumber;
	private String studentName;
	private Double halfYearlyTotal;
	private Double annualTotal;
	private String grade;
	//constructor
	public StudentResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentResult(String rollNumber, String studentName, Double halfYearlyTotal){
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		this.halfYearlyTotal = halfYearlyTotal;
	}
	//getter setter method
	public String getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Double getHalfYearlyTotal() {
		return halfYearlyTotal;
	}
	public void setHalfYearlyTotal(Double halfYearlyTotal) {
		this.halfYearlyTotal = halfYearlyTotal;
	}
	public Double getAnnualTotal() {
		return annualTotal;
	}
	public void setAnnualTotal(Double annualTotal) {
		this.annualTotal = annualTotal;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	//To string method
	@Override
	public String toString() {
		return  rollNumber + "-"+ studentName + "-"+ halfYearlyTotal + "-" + annualTotal + "-" + grade;
	}
}
