package org.anudip.lab;
//Bill Service class
public class BillService {
	public static String billCalculation(Consumer consumer) {
		int units = consumer.getUnitConsumed(); //taking unit consumed from consumer class
		double totalCharge = 0.0;
		//calculating payment amount  
			if (units <= 200) {
			totalCharge = 300.0;
			}
			else if (units <= 500) {
				totalCharge = 300.0 + (units - 200) * 1.25;
				} 
			else if (units <= 1000) {
				totalCharge = 300.0 + 300.0 + (units - 500) * 1.00;
		        } 
			else {
				totalCharge = 300.0 + 300.0 + 500.0 + (units - 1000) * 0.75;
		            }
		//formatting up to 2 decimal
		String formattedCharge = String.format("%.2f", totalCharge);
		consumer.setFinalPayment(formattedCharge);
		return formattedCharge;
		}
	}