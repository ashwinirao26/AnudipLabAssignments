package org.anudip.application;
import java.util.Scanner;
import java.text.DecimalFormat;

public class CircleApp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter radious of a circle: ");
		Double radious = Double.parseDouble(sc.nextLine());
		Circle circle = new Circle(radious);
		double perimeter = circle.perimeterCalculation();
		double area = circle.areaCalculation();
		DecimalFormat myFormat = new DecimalFormat("0.0#");
		String perimeterStr = myFormat.format(perimeter);
		String areaStr = myFormat.format(area);
		System.out.println("Perimeter:"+perimeterStr);
		System.out.println("Area:"+areaStr);
		sc.close();
	}
}
