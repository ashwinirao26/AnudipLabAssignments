package org.anudip.application;
import java.util.Scanner;
import org.anudip.bean.Student;
import org.anudip.service.StudentService;
//import org.anudip.bean.Student;
public class StudentMain {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Student details (roll,name,course,marks) format : ");
		String input = scanner.nextLine();
		String[] inputArray = input.split(",");
		int roll=Integer.parseInt(inputArray[0]);
		double marks = Double.parseDouble(inputArray[3]);
		Student student = new Student(roll,inputArray[1],inputArray[2], marks);
		String grade=StudentService.calculateGrade(student);
		student .setStudentGrade(grade);
		System.out.println(student);
		}
	}
