package org.anudip.application;
import java.util.Scanner;
import org.anudip.bean.Student;
import org.anudip.service.StudentService;

public class StudentArrayMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//ask the number of students record to store
		System.out.println("Enter the number of students:");
		int number = Integer.parseInt(sc.nextLine());
		//array declaration
		Student[] studArr = new Student[number];
		//within loop n  students details are accepted & stored in array
		for(int i=0;i<studArr.length;i++) {
			int j = i+1;
			System.out.println("Enter Student no "+j+".details in (roll,name,course,marks) format : ");
			String input = sc.nextLine();
			String[] inputArray = input.split(",");
			int roll=Integer.parseInt(inputArray[0]);
			double marks = Double.parseDouble(inputArray[3]);
			Student student = new Student(roll,inputArray[1],inputArray[2], marks);
		String grade = StudentService.calculateGrade(student);
		student.setStudentGrade(grade);
		studArr[i]=student;
		} // end of for loop
		//Printing
		String headings= String.format("%-5s %-10s %-10s %-10s %-5s","roll","name","course","marks","grade");
		System.out.println(headings);
		for(Student std:studArr) {
			System.out.println(std);
		}
	}
}