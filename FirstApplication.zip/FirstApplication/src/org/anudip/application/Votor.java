package org.anudip.application;

public class Votor {
	public boolean validVotorCheck(int age) {
		if(age>=18) 
			return true;
		else 
			return false;
	}
}
