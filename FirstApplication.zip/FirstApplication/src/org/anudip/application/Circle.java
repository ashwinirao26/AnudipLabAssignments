package org.anudip.application;

public class Circle {
	private Double radious;
	
	public Circle(Double radious) {
		super();
		this.radious = radious;
	}
	public Double perimeterCalculation() {
		double perimeter = 2*3.1416*radious;
		return perimeter;
	}
	
	public Double areaCalculation() {
		double area = 3.1416*radious*radious;
		return area;
	}	
}
