package org.anudip.exception;

public class AgeException extends RuntimeException {
	static final long serialVersionUID = 1L;
	  public AgeException(String message) {
	        super(message);
	    }
}
