package org.anudip.interfaceApp;

public interface DemoFace {
	public void show();
	public void display();
	public void putdata();
}
