package org.anudip.interfaceApp;
import java.text.DecimalFormat;

public class Circle implements Shape {
	private double radius;
	
	public Circle() {
		this.radius = radius;
	}
    // Calculate the perimeter (circumference) of the circle
    public String perimeter() {
        double perimeter = 2 * pi * radius;
        return formatDecimal(perimeter);
    }

    // Calculate the area of the circle
    public String area() {
        double area = pi * radius * radius;
        return formatDecimal(area);
    }

 // Helper method to format the double value to 2 decimal places
    private String formatDecimal(double value) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(value);
    }
}
