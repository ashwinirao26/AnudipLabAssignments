package org.anudip.interfaceApp;

public class DemoApp {

	public static void main(String[] args) {
		DemoFace df = new DemoFaceImpl();
		df.show();
		df.display();
		df.putdata();
	}
}
