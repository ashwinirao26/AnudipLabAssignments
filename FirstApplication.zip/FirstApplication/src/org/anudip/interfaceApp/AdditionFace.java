package org.anudip.interfaceApp;

public interface AdditionFace {
	public int add(int x,int y);
}
