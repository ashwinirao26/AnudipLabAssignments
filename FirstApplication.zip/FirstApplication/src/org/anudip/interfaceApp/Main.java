package org.anudip.interfaceApp;

public class Main {

	public static void main(String[] args) {
		Circle c = new Circle();
		System.out.println("Circle Perimeter is: "+c.perimeter());
		System.out.println("Circle Area: "+c.area());
	}
}
