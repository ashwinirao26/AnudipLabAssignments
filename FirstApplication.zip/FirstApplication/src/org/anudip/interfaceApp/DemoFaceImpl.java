package org.anudip.interfaceApp;

public class DemoFaceImpl implements DemoFace {
	public void show() {
	System.out.println("Hello everybody");
	}
	public void display() {
		System.out.println("Hi everybody");
	}
	public void putdata() {
		System.out.println("Hello Hi");
	}
}
