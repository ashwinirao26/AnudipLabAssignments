package org.anudip.string;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String s = sc.nextLine(); //taking string input
		StringBuilder sb = new StringBuilder(s);
		sb.reverse(); // reversing the string by using reverse function
		String rev = sb.toString(); // converting sb to string
		if(s.equalsIgnoreCase(rev)) { // comparing string after reversing by ignoring case
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not Palindrome");
		}
	}
}
