package org.anudip.string;

import java.util.Scanner;

public class StringDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Name");
		String s = sc.nextLine();
		String name = s.toLowerCase();
		
		if(name.startsWith("mr")) {
			System.out.println("Good Afternoon "+"Sir");
		}
		else if(name.startsWith("mrs") || name.startsWith("ms")) {
			System.out.println("Good Afternoon "+"Madam");
		}
		else {
			System.out.println("Good Afternoon "+s);
			
		}
	}
}
