package org.anudip.string;

public class StringDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "ABCD";
		int s = str.length(); //size of the 
		System.out.println("The length of the string is "+s);
		//convert into char array
		char[] arr = str.toCharArray();
//		for(int i=0; i<arr.length; i++) {
//			System.out.print(arr[i]+" ");
//		}
		
	//printing using for each loop
		for(char c:arr) {
			System.out.print(c+" ");
		}
		
	}
}
