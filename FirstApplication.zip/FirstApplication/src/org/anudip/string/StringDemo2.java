package org.anudip.string;

import java.util.Scanner;

public class StringDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Name of a person");
		String pName = sc.nextLine();
		if(pName.endsWith("a") || pName.endsWith("i")) {
			System.out.println("Name of a girl");
		}
		else {
			System.out.println("Name of a boy");
		}
	}

}
