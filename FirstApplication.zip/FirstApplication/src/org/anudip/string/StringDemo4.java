package org.anudip.string;

public class StringDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "ABCDEFGHIJ";
		String str = s.substring(3);
		System.out.println(str);
		String st = s.substring(3,7);
		System.out.println(st);
	}

}
