package org.anudip.string;

import java.util.Scanner;

public class StringDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String s = sc.nextLine();
		System.out.println("Enter first index");
		int n = sc.nextInt();
		n--;
		System.out.println("Enter last index");
		int m = sc.nextInt();
		m=m+n;
		String str = s.substring(n,m);
		System.out.println(str);
	}

}
