package flower;

public class AllDemoMain {

	public static void main(String[] args) {
		AllDemo ad1 = new AllDemo();
		ad1.show();
		AllDemo ad2 = new AllDemo();
		ad2.show();
		AllDemo ad3 = new AllDemo();
		ad3.show();
		AllDemo.display();
	}
}
