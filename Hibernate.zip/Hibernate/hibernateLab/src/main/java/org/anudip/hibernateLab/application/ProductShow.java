package org.anudip.hibernateLab.application;
import java.util.List;
import org.anudip.hibernateLab.bean.Product;
import org.anudip.hibernateLab.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class ProductShow {
	public static void main(String[] args) throws Exception {
		// Get an instance of the DatabaseHandler
		DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
		// Create a new Hibernate session
		Session session = dbHandler.createSession();
		// Define a HQL (Hibernate Query Language) query statement to retrieve all
		// products
		String queryStatement = "from Product";
		// Create a query object using the session and the HQL statement
		Query<Product> query = session.createQuery(queryStatement);
		// Execute the query and retrieve a list of products
		List<Product> productList = query.list();
		// Iterate through the list of products and print each product
		productList.forEach(product -> System.out.println(product));
		// Close the Hibernate session
		session.close();
	}
}