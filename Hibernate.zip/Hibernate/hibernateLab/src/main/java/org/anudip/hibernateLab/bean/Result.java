package org.anudip.hibernateLab.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Result")
public class Result {
	// Member Data
	@Id
	@Column(name = "roll_number")
	private String rollNumber;
	@Column(name = "halfYearly_total")
	private Double halfYearlyTotal;
	@Column(name = "annual_total")
	private Double annualTotal;
	@Column(name = "grade")
	private String grade;

	// Constructors
	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal, String grade) {
		super();
		this.rollNumber = rollNumber;
		this.halfYearlyTotal = halfYearlyTotal;
		this.annualTotal = annualTotal;
		this.grade = grade;
	}

	// Getter & Setter
	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public Double getHalfYearlyTotal() {
		return halfYearlyTotal;
	}

	public void setHalfYearlyTotal(Double halfYearlyTotal) {
		this.halfYearlyTotal = halfYearlyTotal;
	}

	public Double getAnnualTotal() {
		return annualTotal;
	}

	public void setAnnualTotal(Double annualTotal) {
		this.annualTotal = annualTotal;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	// To String Method
	@Override
	public String toString() {
		String output = String.format("%-20s -20s %-20s %-5s", rollNumber, halfYearlyTotal, annualTotal, grade);
		return output;
	}
}
