package org.anudip.hibernateLab.application;
import java.util.Scanner;
import org.anudip.hibernateLab.bean.EssentialCommodityException;
import org.anudip.hibernateLab.bean.GradeMismatchException;
import org.anudip.hibernateLab.bean.PriceException;
import org.anudip.hibernateLab.bean.Product;
import org.anudip.hibernateLab.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProductEntry {
	public static void main(String[] args) throws Exception {
		//Accepting Input
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the number of items to accept: ");
		int numItems = scanner.nextInt();
		scanner.nextLine(); // Clear the newline character from the buffer
		//Product array
		Product[] productArr = new Product[numItems];
		System.out.println(
				"Enter the item details in comma-separated format (id, name, purchasedPrice, salesPrice, grade):");
		for (int i = 0; i < numItems; i++) {
			System.out.println("Enter product " + (i + 1) + ":");
			String product = scanner.nextLine();
			String[] arr = product.split(",");
			int id = Integer.parseInt(arr[0]);
			String name = arr[1];
			double purchasedPrice = Double.parseDouble(arr[2]);
			double salesPrice = Double.parseDouble(arr[3]);
			String grade = arr[4];
			String eCarry = "E";
			String nCarry = "N";
			try {
				// check,if sales price lower than purchase price then throw an exception
				if (salesPrice < purchasedPrice) {
					throw new PriceException("Sales price must be higher than purchase price");
				}
				// check,if the product grade is wrong then throw an exception
				else if (!(grade.equals(eCarry) || grade.equals(nCarry))) {
					throw new GradeMismatchException("Wrong grade");
				}
				// check,if E graded product sales price is greater than 25% of purchase price
				// then throw an exception
				else if (grade.equals(eCarry) && (salesPrice > purchasedPrice + (0.25 * purchasedPrice))) {
					throw new EssentialCommodityException(
							"Sales price for essential commodity cannot be more than 25% of purchase price");
				}
				else {
					Product products = new Product(id, name, purchasedPrice, salesPrice, grade);
					DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
					Session session = dbHandler.createSession();
					Transaction transaction = session.beginTransaction();
					session.persist(products);
					transaction.commit();
					session.close();
					System.out.println("New Record Added");
				}
			} // end of try
			catch (PriceException pe) {
				System.out.println("PriceException : " + pe.getMessage());
			} // end of catch
			catch (EssentialCommodityException ece) {
				System.out.println("EssentialCommodityException : " + ece.getMessage());
			} // end of catch
			catch (GradeMismatchException ge) {
				System.out.println("GradeMismatchException : " + ge.getMessage());
			} // end of catch
		}// end of loop
	} //end of main 
} //end of class
