package org.anudip.hibernateLab.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class Student {
	// Member Data
	@Id
	@Column(name = "roll_number")
	private String rollNumber;
	@Column(name = "student_name")
	private String studentName;
	@Column(name = "semester")
	private String semester;
	@OneToOne(fetch = FetchType.LAZY, targetEntity = Result.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "roll_number")

	private Result studentResult;

	// Constructors
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String rollNumber, String studentName, String semester, Result studentResult) {
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		this.semester = semester;
		this.studentResult = studentResult;
	}

	// Getter & Setter
	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public Result getStudentResult() {
		return studentResult;
	}

	public void setStudentResult(Result studentResult) {
		this.studentResult = studentResult;
	}

	// To String Method
	@Override
	public String toString() {
		String output = String.format("%-5s %-20s %-5s %-2s", rollNumber, studentName, semester, studentResult);
		return output;
	}

}
