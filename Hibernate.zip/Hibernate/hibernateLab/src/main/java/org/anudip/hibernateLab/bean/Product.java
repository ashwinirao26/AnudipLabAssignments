package org.anudip.hibernateLab.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product implements Comparable<Product>{
		@Id
		@Column(name="product_id")
		private Integer productId;
		@Column(name="product_name")
		private String productName;
		@Column(name = "purchased_price")
	    private Double purchasedPrice;
	    @Column(name = "sales_price")
	    private Double salesPrice;
	    @Column(name = "grade")
	    private String grade;
	    //Constructors
		public Product() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Product(Integer productId, String productName, Double purchasedPrice, Double salesPrice, String grade) {
			super();
			this.productId = productId;
			this.productName = productName;
			this.purchasedPrice = purchasedPrice;
			this.salesPrice = salesPrice;
			this.grade = grade;
		}
		//Getter and Setter
		public Integer getProductId() {
			return productId;
		}
		public void setProductId(Integer productId) {
			this.productId = productId;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public Double getPurchasedPrice() {
			return purchasedPrice;
		}
		public void setPurchasedPrice(Double purchasedPrice) {
			this.purchasedPrice = purchasedPrice;
		}
		public Double getSalesPrice() {
			return salesPrice;
		}
		public void setSalesPrice(Double salesPrice) {
			this.salesPrice = salesPrice;
		}
		public String getGrade() {
			return grade;
		}
		public void setGrade(String grade) {
			this.grade = grade;
		}
		//To String Method
		@Override
		public String toString() {
			String output=String.format("%-5s %-20s %-10s %-10s %-5s",productId,productName,purchasedPrice,salesPrice,grade);
			return output;
		}
		//Comparable Interface
		@Override
	    public int compareTo(Product other) {
	        return this.productId.compareTo(other.productId);
	    }
		
}
