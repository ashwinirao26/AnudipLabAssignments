package org.anudip.mavenApplication;
import static org.junit.jupiter.api.Assertions.*;
import org.anudip.mavenApplication.app.Employee;
import org.anudip.mavenApplication.app.EmployeeService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
class EmployeeServiceTest {
	private static Employee employee;
	private static EmployeeService empService;
	
	@BeforeAll
	public static void init() {
		empService = new EmployeeService();
	}
	@Disabled
	@Test
	void testTaxCalculation1() {
		Employee employee = new Employee(505,"Hilda Hill",75000.00);
		String expected = "90000.00";
		String actual = new EmployeeService().taxCalculation(employee);
		System.out.println("Test1");
		assertEquals(expected,actual);
	}
	
	@Test
	void testTaxCalculation2() {
		Employee employee = new Employee(505,"Hilda Hill",125000.00);
		String expected = "375000.00";
		String actual = empService.taxCalculation(employee);
		System.out.println("Test2");
		assertEquals(expected,actual);
	}
}
