package org.anudip.mavenApplication.collection;
import java.util.PriorityQueue;

public class PriorityQueueDemo1 {
	public static void main(String[] args) {
		PriorityQueue<String> myQueue = new PriorityQueue<String>();
		System.out.println("Original List");
		myQueue.add("Mango");
		myQueue.add("Apple");
		myQueue.add("Banana");
		myQueue.add("Plum");
		myQueue.add("Pinapple");
		myQueue.add("Litchi");
//		myQueue.forEach(str->System.out.println(str));
//		System.out.println("Polling");
//		System.out.println(myQueue.poll());
//		System.out.println("After Polling the queue is:");
//		myQueue.forEach(str->System.out.println(str));
		myQueue.forEach(str->System.out.println(str));
		System.out.println("Peeking");
		System.out.println(myQueue.peek());
		System.out.println("After Peeking the queue is:");
		myQueue.forEach(str->System.out.println(str));
	}
}
