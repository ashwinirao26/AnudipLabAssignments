package org.anudip.mavenApplication.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ArrayListDemo3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter numbers of products to store:");
		int no = Integer.parseInt(scanner.nextLine());
		ArrayList<Item> itemList = new ArrayList<Item>();
		for(int i=0; i<no; i++) {
			System.out.println("Enter product details in comma(,) separated String:");
			String stg = scanner.nextLine();
			String[] arr= stg.split(",");
			int id = Integer.parseInt(arr[0]);
			double price = Double.parseDouble(arr[2]);
			Item item = new Item(id,arr[1],price);
			itemList.add(item);
		}//end of loop
		System.out.println("Display in order of entry");
		System.out.println("--------------------------");
		itemList.forEach(prod->System.out.println(prod));
		System.out.println("Display in ascending order of Product Id");
		System.out.println("----------------------------------------");
		Collections.sort(itemList,new IdComparator());
		itemList.forEach(prod->System.out.println(prod));
		System.out.println("Display in ascending order of Product Name");
		System.out.println("-----------------------------------------");
		Collections.sort(itemList,new NameComparator());
		itemList.forEach(prod->System.out.println(prod));
		System.out.println("Display in ascending order of Product Price");
		System.out.println("-----------------------------------------");
		Collections.sort(itemList,new PriceComparator());
		itemList.forEach(prod->System.out.println(prod));
	scanner.close();
	}
}
	
