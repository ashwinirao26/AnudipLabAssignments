package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataShow {
	public static void main(String[] args) throws Exception{
		// Load the database(MySQL driver/ Database specific driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		//Connect to database
		Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/c5904","root","root");
		//Create sql statement
		String sqlStatement = "Select * from department";
		// create link with table to fire query & exchange data
		Statement statement = connection.createStatement();
		//Fire sql query & receive data in a tabular format
		ResultSet resultSet = statement.executeQuery(sqlStatement);
		// extract every row from ResultSet; Whether next row/record exist or not
		while(resultSet.next()) {
			int id = resultSet.getInt(1);
			String name = resultSet.getString(2);
			String location = resultSet.getString(3);
			System.out.println(id+" "+name+" "+location);	
		}//end of loop
		connection.close();
	}
}
