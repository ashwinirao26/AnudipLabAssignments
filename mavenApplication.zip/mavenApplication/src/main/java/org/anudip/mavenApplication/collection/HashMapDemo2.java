package org.anudip.mavenApplication.collection;
import java.util.HashMap;
import java.util.Set;

public class HashMapDemo2 {
	public static void main(String[] args) {
		HashMap<Integer,String> myMap = new HashMap<>();
		myMap.put(103,"Rose");
		myMap.put(105,"Tulip");
		myMap.put(101,"Cosmos");
		myMap.put(104,"Rose");
		myMap.put(102,"Mariegold");
		myMap.put(106,"Lotus");
		myMap.put(102,"Lily");
		Set<Integer> allKeys = myMap.keySet();
		System.out.println(allKeys);
		for(Integer ig: allKeys) {
			String str = myMap.get(ig);
			System.out.println(ig+"-"+str);
		}
	}
}
