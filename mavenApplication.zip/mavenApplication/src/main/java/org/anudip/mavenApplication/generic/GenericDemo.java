package org.anudip.mavenApplication.generic;

public class GenericDemo<T> {
	//Here T represents any data type
	public void swapData(T x, T y) {
		System.out.println("Before swapping value of x: "+x+" Value of y: "+y);
		T z = x;
		x=y;
		y=z;
		System.out.println("After swapping value of x: "+x+" Value of y: "+y);
	}
}
