package org.anudip.mavenApplication.single;

public class SingleMain {

	public static void main(String[] args) {
		SingleDemo sd1 = SingleDemo.getSingleDemo();
		System.out.println("From sd1: "+sd1.getdata());
		sd1.putdata(15);
		System.out.println("From sd1: "+sd1.getdata());
		SingleDemo sd2 = SingleDemo.getSingleDemo();
		System.out.println("From sd2: "+sd2.getdata());
	}
}