package org.anudip.mavenApplication.collection;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo1 {
	public static void main(String[] args) {
		LinkedHashSet<String> mySet = new LinkedHashSet<String>();
		mySet.add("Rose");
		mySet.add("Lotus");
		mySet.add("Lily");
		mySet.add("Jasmine");
		mySet.add("Sunflower");
		mySet.add("Marigold");
		mySet.add("Cosmo");
		mySet.add("Jasmine");
		mySet.add("Delhia");
		mySet.add("Zenia");
		mySet.add("Tulip");
		mySet.add("Sunflower");
		System.out.println("Display:");
		mySet.forEach(str->System.out.println(str));
		//System.out.println("Displaying in descending order");
	}
}
