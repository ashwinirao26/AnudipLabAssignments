package org.anudip.mavenApplication.collection;
import java.util.TreeSet;

public class TreeSetDemo2 {
	
	public static void main(String[] args) {
		TreeSet<String> mySet = new TreeSet<String>();
		mySet.add("Rose");
		mySet.add("Lotus");
		mySet.add("Lily");
		mySet.add("Jasmine");
		mySet.add("Sunflower");
		mySet.add("Marigold");
		mySet.add("Cosmo");
		mySet.add("Jasmine");
		mySet.add("Delhia");
		mySet.add("Zenia");
		mySet.add("Tulip");
		System.out.println("Displaying in ascending order");
		mySet.forEach(str->System.out.println(str));
		//System.out.println("Displaying in descending order");
	}
}
