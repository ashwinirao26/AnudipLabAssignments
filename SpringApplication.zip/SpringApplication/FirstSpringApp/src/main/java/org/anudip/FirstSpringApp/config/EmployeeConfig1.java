package org.anudip.FirstSpringApp.config;
import org.anudip.FirstSpringApp.bean.Address;
import org.anudip.FirstSpringApp.bean.Employee;
import org.springframework.context.annotation.Bean;

// It is act as constructor based Dependency Injection

public class EmployeeConfig1 {
	@Bean
	public Address address() {
		return new Address("16,Park Street", "Kolkata", 700016);
	}

	@Bean
	public Employee employee() {
		return new Employee(10005, "Erica Joseph", address(), 65000.00);
	}

}
