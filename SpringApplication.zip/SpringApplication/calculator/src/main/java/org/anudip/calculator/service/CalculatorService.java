package org.anudip.calculator.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorService {
//	public static int performCalculation(String operand1, String operand2, String operator) {
//		int num1 = Integer.parseInt(operand1);
//		int num2 = Integer.parseInt(operand2);
//		switch (operator) {
//		case "+":
//			return num1 + num2;
//		case "-":
//			return num1 - num2;
//		case "x":
//			return num1 * num2;
//		case "/":
//			return num1 / num2;
//		default:
//			throw new IllegalArgumentException("Invalid operator: " + operator);
//		}
	public String performCalculation(int i, int j, String k) {
		int r = 0;
		String result = "";
		switch (k) {
		case "+":
			r = i + j;
			result = "" + r;
			break;
		case "-":
			r = i - j;
			result = "" + r;
			break;
		case "*":
			r = i * j;
			result = "" + r;
			break;
		case "/":
			r = i / j;
			result = "" + r;
			break;
		case "%":
			r = i % j;
			result = "" + r;
			break;
		default:
			result = "ABCD";
		}
		return result;
	}
}
