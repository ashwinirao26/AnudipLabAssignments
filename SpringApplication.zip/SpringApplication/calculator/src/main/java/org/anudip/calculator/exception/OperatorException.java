package org.anudip.calculator.exception;

public class OperatorException extends RuntimeException {

}
