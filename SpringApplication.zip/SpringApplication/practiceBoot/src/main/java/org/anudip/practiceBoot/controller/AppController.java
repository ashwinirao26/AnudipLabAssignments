package org.anudip.practiceBoot.controller;

import org.anudip.practiceBoot.service.PalindromeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class AppController {
	@Autowired
	PalindromeService pService;

	@GetMapping("/index")
	public ModelAndView showIndexPage() {
		ModelAndView mv = new ModelAndView("indexPage");
		return mv;
	}

	@GetMapping("/accept")
	public ModelAndView showAcceptPage() {
		return new ModelAndView("acceptPage");
	}

	@PostMapping("/palindrome-check")
	public ModelAndView showPalindromeResult(@RequestParam("mystr") String str) {
		boolean flag = pService.palindromeCheck(str);
		String msg = "";
		if (flag)
			msg = str + " is Palindrome";
		else
			msg = str + " is not Palindrome";
		ModelAndView mv = new ModelAndView("displayPage");
		mv.addObject("message", msg);
		return mv;
	}
}