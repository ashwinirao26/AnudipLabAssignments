package org.anudip.practiceBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeBootApplication.class, args);
	}

}
