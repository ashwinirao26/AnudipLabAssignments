package org.anudip.practiceBoot.service;

import org.springframework.stereotype.Service;

@Service
public class PalindromeService {

	public boolean palindromeCheck(String str) {
		boolean flag = true;
		String rev = "";
		for (int i = str.length() - 1; i >= 0; i--) {
			rev = rev + str.charAt(i);
			if (str.equalsIgnoreCase(rev)) {
				flag = true;
			}
			else flag = false;
		}
		return flag;
	}
}