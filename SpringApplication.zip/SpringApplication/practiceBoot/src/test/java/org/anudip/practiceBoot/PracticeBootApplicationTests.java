package org.anudip.practiceBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
