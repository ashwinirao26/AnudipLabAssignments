package org.anudip.autowireApp.application;

import org.anudip.autowireApp.bean.Company;
import org.anudip.autowireApp.config.CompanyConfig1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CompanyMain {

	public static void main(String[] args) throws Exception {
		ApplicationContext appContext = new AnnotationConfigApplicationContext(CompanyConfig1.class);
		Company com = appContext.getBean(Company.class);
		System.out.println(com);
	}

}