package org.anudip.autowireApp.config;

import org.anudip.autowireApp.bean.Address;
import org.anudip.autowireApp.bean.Employee;
import org.springframework.context.annotation.Bean;

public class EmployeeConfig1 {

	@Bean
	public Address address() {
		return new Address("78,Aminabad Road", "Hyderabad", 500028);
	}

	@Bean
	public Employee employee() {
		return new Employee(10003, "Stella Louis", address(), 50000.00);
	}

}