package org.anudip.courseCrud.service;

import org.anudip.courseCrud.bean.Course;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
	public Course gstAndTotalFeeCalculation(Course course) {
		double coursePrice = course.getCoursePrice();
		double gst = coursePrice * 0.125;
		double totalFee = coursePrice + gst;
		course.setGst(gst);
		course.setTotalFee(totalFee);
		return course;
	}
}
