package org.anudip.courseCrud.controller;

import java.util.List;
import org.anudip.courseCrud.bean.Course;
import org.anudip.courseCrud.dao.CourseDao;
import org.anudip.courseCrud.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseRestController {
	@Autowired
	private CourseDao courseDao;
	@Autowired
	private CourseService service;

	@GetMapping(value = "/my-coursesj", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Course> showAllCoursesPageJson() {

		List<Course> courseList = courseDao.displayAllCourses();
		return courseList;
	}

	@GetMapping(value = "/my-coursesx", produces = MediaType.APPLICATION_XML_VALUE)
	public List<Course> showAllCoursesPageXml() {

		List<Course> courseList = courseDao.displayAllCourses();
		return courseList;
	}

	@PostMapping(value = "/my-coursesj", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String acceptInput1(@RequestBody Course course) {
		Long id = courseDao.generateNewCourseId();
		course.setCourseId(id);
		Course newCourse = service.gstAndTotalFeeCalculation(course);
		courseDao.saveCourse(newCourse);
		return "New Course Added With Id";
	}

	@PostMapping(value = "/my-coursesx", consumes = MediaType.APPLICATION_XML_VALUE)
	public String acceptInput2(@RequestBody Course course) {
		Long id = courseDao.generateNewCourseId();
		course.setCourseId(id);
		Course newCourse = service.gstAndTotalFeeCalculation(course);
		courseDao.saveCourse(newCourse);
		return "New Course Added With Id";
	}

	@PutMapping(value = "/my-coursesj", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateCourseJ(@RequestBody Course course) {
		Course course2 = courseDao.findACourseById(course.getCourseId());
		course2.setCoursePrice(course.getCoursePrice());
		Course newCourse = service.gstAndTotalFeeCalculation(course2);
		courseDao.saveCourse(newCourse);
		return "Course Price Updated";
	}

	@PutMapping(value = "/my-coursesx", consumes = MediaType.APPLICATION_XML_VALUE)
	public String updateCourseX(@RequestBody Course course) {
		Course course2 = courseDao.findACourseById(course.getCourseId());
		course2.setCoursePrice(course.getCoursePrice());
		Course newCourse = service.gstAndTotalFeeCalculation(course2);
		courseDao.saveCourse(newCourse);
		return "Course Price Updated";
	}

}
