package org.anudip.courseCrud.dao;

import java.util.List;
import org.anudip.courseCrud.bean.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
@Repository
public class CourseDaoImpl implements CourseDao {
	@Autowired
	private CourseRepository repository;

	@Override
	public void saveCourse(Course course) {
		repository.save(course);
	}

	@Override
	public List<Course> displayAllCourses() {
		return repository.findAll();
	}

	@Override
	public Course findACourseById(Long courseId) {
		return repository.findById(courseId).get();
	}

	@Override
	public Long generateNewCourseId() {
		long newId = 1001;
		int val = repository.getCourseCount();
		if (val > 0)
		newId = newId + val;
		return newId;
	}

	@Override
	public void deleteCourseById(Long courseId) {
		repository.deleteById(courseId);
	}
	
	@Override
	public List<Long> getAllCourseIds(){
		return repository.getAllCourseIds();
	}

}
